#include <iostream>
#include <fstream>
#include <map>
#include <string>
/// Kaley Faucher
/// Project 3
/// August 20, 2024
using namespace std;

class ItemTracker {
private:
    map<string, int> itemFrequency;

public:
    void readFile() {
        ifstream inputFile("CS210_Project_Three_Input_File.txt");
        string item;

        while (inputFile >> item) {
            itemFrequency[item]++;
        }

        inputFile.close();
    }

    void displayItemFrequency(const string& item) {
        cout << "Frequency of " << item << ": " << itemFrequency[item] << endl;
    }

    void displayAllItemFrequency() {
        for (const auto& pair : itemFrequency) {
            cout << pair.first << " " << pair.second << endl;
        }
    }

    void displayHistogram() {
        for (const auto& pair : itemFrequency) {
            cout << pair.first << " ";
            for (int i = 0; i < pair.second; ++i) {
                cout << "*";
            }
            cout << endl;
        }
    }

    void backupData() {
        ofstream outputFile("frequency.dat");

        if (outputFile.is_open()) {
            for (const auto& pair : itemFrequency) {
                outputFile << pair.first << " " << pair.second << endl;
            }
            outputFile.close();
        }
        else {
            cout << "Unable to open file for backup." << endl;
        }
    }
};

int main() {
    ItemTracker tracker;
    tracker.readFile();
    tracker.backupData();

    int choice;
    string item;
    do {
        cout << "Menu:" << endl;
        cout << "1. Find frequency of a specific item" << endl;
        cout << "2. Display frequency of all items" << endl;
        cout << "3. Display histogram of item frequency" << endl;
        cout << "4. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter the item you wish to look for: ";
            cin >> item;
            tracker.displayItemFrequency(item);
            break;
        case 2:
            tracker.displayAllItemFrequency();
            break;
        case 3:
            tracker.displayHistogram();
            break;
        case 4:
            cout << "Exiting program. Goodbye!" << endl;
            break;
        default:
            cout << "Invalid choice. Please enter a number between 1 and 4." << endl;
        }
    } while (choice != 4);

    return 0;
}